#include <stdio.h>
#include <stdlib.h>
#include "operations.h"

// Sentinel NIL node definition
static tree_t NIL_NODE = {0, BLACK, NULL, NULL, NULL};
static tree_t *NIL = &NIL_NODE;
static int nil_initialized = 0;

static void init_nil(void) {
    if (!nil_initialized) {
        NIL_NODE.left = NIL;
        NIL_NODE.right = NIL;
        NIL_NODE.parent = NIL;
        nil_initialized = 1;
    }
}

static tree_t* create_node(data_t item) {
    init_nil();
    tree_t *new_node = (tree_t*)malloc(sizeof(tree_t));
    if (new_node == NULL) return NULL;
    
    new_node->element = item;
    new_node->colour = RED;
    new_node->left = NIL;
    new_node->right = NIL;
    new_node->parent = NIL;
    
    return new_node;
}

static void left_rotate(tree_t **root, tree_t *x) {
    tree_t *y = x->right;
    x->right = y->left;
    
    if (y->left != NIL) {
        y->left->parent = x;
    }
    
    y->parent = x->parent;
    
    if (x->parent == NIL) {
        *root = y;
    } else if (x == x->parent->left) {
        x->parent->left = y;
    } else {
        x->parent->right = y;
    }
    
    y->left = x;
    x->parent = y;
}

static void right_rotate(tree_t **root, tree_t *y) {
    tree_t *x = y->left;
    y->left = x->right;
    
    if (x->right != NIL) {
        x->right->parent = y;
    }
    
    x->parent = y->parent;
    
    if (y->parent == NIL) {
        *root = x;
    } else if (y == y->parent->right) {
        y->parent->right = x;
    } else {
        y->parent->left = x;
    }
    
    x->right = y;
    y->parent = x;
}

static void insert_fixup(tree_t **root, tree_t *z) {
    while (z->parent->colour == RED) {
        if (z->parent == z->parent->parent->left) {
            tree_t *uncle = z->parent->parent->right;
            if (uncle->colour == RED) {
                z->parent->colour = BLACK;
                uncle->colour = BLACK;
                z->parent->parent->colour = RED;
                z = z->parent->parent;
            } else {
                if (z == z->parent->right) {
                    z = z->parent;
                    left_rotate(root, z);
                }
                z->parent->colour = BLACK;
                z->parent->parent->colour = RED;
                right_rotate(root, z->parent->parent);
            }
        } else {
            tree_t *uncle = z->parent->parent->left;
            if (uncle->colour == RED) {
                z->parent->colour = BLACK;
                uncle->colour = BLACK;
                z->parent->parent->colour = RED;
                z = z->parent->parent;
            } else {
                if (z == z->parent->left) {
                    z = z->parent;
                    right_rotate(root, z);
                }
                z->parent->colour = BLACK;
                z->parent->parent->colour = RED;
                left_rotate(root, z->parent->parent);
            }
        }
    }
    if (*root != NULL) {
        (*root)->colour = BLACK;
    }
}

int insert(tree_t **root, data_t item) {
    init_nil();
    if (root == NULL) return FAILURE;

    tree_t *z = create_node(item);
    if (z == NULL) return FAILURE;

    tree_t *y = NIL;
    tree_t *x = (*root == NULL || *root == NIL) ? NIL : *root;

    while (x != NIL) {
        y = x;
        if (z->element < x->element) {
            x = x->left;
        } else if (z->element > x->element) {
            x = x->right;
        } else {
            free(z);
            return FAILURE; // Duplicate
        }
    }

    z->parent = y;
    if (y == NIL) {
        *root = z;
    } else if (z->element < y->element) {
        y->left = z;
    } else {
        y->right = z;
    }

    insert_fixup(root, z);
    return SUCCESS;
}

int search(tree_t **root, data_t item) {
    init_nil();
    if (root == NULL || *root == NULL || *root == NIL) return FAILURE;
    
    tree_t *current = *root;
    while (current != NIL) {
        if (item == current->element) return SUCCESS;
        if (item < current->element) current = current->left;
        else current = current->right;
    }
    return FAILURE;
}

int find_minimum(tree_t **root, data_t *min) {
    init_nil();
    if (root == NULL || *root == NULL || *root == NIL || min == NULL) return FAILURE;

    tree_t *current = *root;
    while (current->left != NIL) {
        current = current->left;
    }
    *min = current->element;
    return SUCCESS;
}

int find_maximum(tree_t **root, data_t *max) {
    init_nil();
    if (root == NULL || *root == NULL || *root == NIL || max == NULL) return FAILURE;

    tree_t *current = *root;
    while (current->right != NIL) {
        current = current->right;
    }
    *max = current->element;
    return SUCCESS;
}

// In-order traversal helper for display matching screenshot format
static void inorder_display(tree_t *root) {
    init_nil();
    if (root != NIL && root != NULL) {
        inorder_display(root->left);
        char *color_str = (root->colour == RED) ? "RED" : "BLACK";
        printf("(%d)--(%s->%d) ", root->element, color_str, root->colour);
        inorder_display(root->right);
    }
}

void display(tree_t *root) {
    init_nil();
    if (root == NULL || root == NIL) {
        printf("Tree is empty.\n");
        return;
    }
    inorder_display(root);
    printf("\n");
}
int delete(tree_t **root, data_t item) {
    init_nil();
    // Not implemented for now
    return FAILURE; 
}

int delete_minimum(tree_t **root) {
    init_nil();
    // Not implemented for now
    return FAILURE;
}

int delete_maximum(tree_t **root) {
    init_nil();
    // Not implemented for now
    return FAILURE;
}