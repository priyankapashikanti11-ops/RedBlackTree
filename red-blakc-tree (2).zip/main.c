#include <stdio.h>
#include "operations.h"

int main(void) {
    tree_t *root = NULL;
    int choice;
    data_t element;
    char ch;

    do {
        printf("\n1.Create a Tree\n");
        printf("2.Display\n");
        printf("3.Search a node\n");
        printf("4.Find Maximum node in Tree\n");
        printf("5.Find Minimum node in Tree\n");
        printf("6.Deletion\n");
        printf("7.Delete Minimum node\n");
        printf("8.Delete Maximum node\n");
        printf("9.Exit\n");
        printf("Enter the choice : ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the element : ");
                scanf("%d", &element);
                if (insert(&root, element) == SUCCESS) {
                    printf("Now Tree is balance\n");
                } else {
                    printf("Insertion failed or duplicate element.\n");
                }
                break;

            case 2:
                printf("Tree Elements: \n");
                display(root);
                break;

            case 3:
                printf("Enter element to search: ");
                scanf("%d", &element);
                if (search(&root, element) == SUCCESS) {
                    printf("Element %d found in tree.\n", element);
                } else {
                    printf("Element %d not found.\n", element);
                }
                break;

            case 4: {
                data_t max_val;
                if (find_maximum(&root, &max_val) == SUCCESS) {
                    printf("Maximum node in Tree: %d\n", max_val);
                } else {
                    printf("Tree is empty.\n");
                }
                break;
            }

            case 5: {
                data_t min_val;
                if (find_minimum(&root, &min_val) == SUCCESS) {
                    printf("Minimum node in Tree: %d\n", min_val);
                } else {
                    printf("Tree is empty.\n");
                }
                break;
            }

            case 6:
                printf("Enter element to delete: ");
                scanf("%d", &element);
                if (delete(&root, element) == SUCCESS) {
                    printf("Deleted successfully.\n");
                } else {
                    printf("Deletion not implemented or element not found.\n");
                }
                break;

            case 7:
                if (delete_minimum(&root) == SUCCESS) {
                    printf("Deleted minimum node.\n");
                } else {
                    printf("Operation failed.\n");
                }
                break;

            case 8:
                if (delete_maximum(&root) == SUCCESS) {
                    printf("Deleted maximum node.\n");
                } else {
                    printf("Operation failed.\n");
                }
                break;

            case 9:
                printf("Exiting...\n");
                return 0;

            default:
                printf("Invalid choice!\n");
        }

        printf("Do u want to continue(y/n) : ");
        scanf(" %c", &ch);

    } while (ch == 'y' || ch == 'Y');

    return 0;
}