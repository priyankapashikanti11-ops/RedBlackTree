#ifndef OPERATIONS_H
#define OPERATIONS_H

#define SUCCESS 1
#define FAILURE 0

typedef int data_t;

typedef enum {
    RED = 0,
    BLACK = 1
} COLOUR;

typedef struct Node {
    data_t element;
    COLOUR colour;
    struct Node *right;
    struct Node *left;
    struct Node *parent;
} tree_t;

// Required Prototypes
int insert(tree_t **root, data_t item);
int search(tree_t **root, data_t item);
int find_minimum(tree_t **root, data_t *min);
int find_maximum(tree_t **root, data_t *max);
int delete(tree_t **root, data_t item);
int delete_minimum(tree_t **root);
int delete_maximum(tree_t **root);
void display(tree_t *root);

#endif